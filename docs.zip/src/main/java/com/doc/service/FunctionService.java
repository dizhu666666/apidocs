package com.doc.service;

import com.doc.entity.DocsFunction;

public interface FunctionService extends BaseService<DocsFunction>{
 

}
