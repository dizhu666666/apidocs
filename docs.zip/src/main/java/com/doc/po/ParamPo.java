package com.doc.po;

public class ParamPo {
	private String reqColumn;
	private String resColumn;
	private Long menuId;
	
	public Long getMenuId() {
		return menuId;
	}
	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}
	public String getReqColumn() {
		return reqColumn;
	}
	public void setReqColumn(String reqColumn) {
		this.reqColumn = reqColumn;
	}
	public String getResColumn() {
		return resColumn;
	}
	public void setResColumn(String resColumn) {
		this.resColumn = resColumn;
	}
	
	
}
