package com.doc.util;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class TopitTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3002643386716386520L;
	private String value; // 处理的字符串

	public void setValue(String value) {
		this.value = value;
	}

	public int doStartTag() throws JspException {
		String newValue = EmojiFilter.emojiRecovery(value);
		JspWriter out = pageContext.getOut();
		try {
			out.write(newValue);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
}
